function onEvent(name, value1, value2)
	-- bf notespin
	noteTweenAngle('A',4 , value2 , value1, linear);
	noteTweenAngle('B',5 , value2 , value1, linear);
	noteTweenAngle('C',6 , value2 , value1, linear);
	noteTweenAngle('D',7 , value2 , value1, linear);
	
	-- oppt notespin
	noteTweenAngle('E',0 , value2 , value1, linear);
	noteTweenAngle('F',1 , value2 , value1, linear);
	noteTweenAngle('G',2 , value2 , value1, linear);
	noteTweenAngle('H',3 , value2 , value1, linear);
	
	
end
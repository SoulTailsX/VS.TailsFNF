function onEvent(n,v1,v2)

	if n == 'Object Play Animation' then
		
		objectPlayAnimation(v1,v2,true)
		
	end

end
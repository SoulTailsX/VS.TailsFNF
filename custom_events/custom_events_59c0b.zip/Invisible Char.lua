function onEvent(name,v1,v2)
	if name == 'Invisible Char' then
		setProperty('dad.alpha', v1)
	end
end
function onEvent(n,v,b)

if n == 'DanceSpeed' then
	setProperty('boyfriend.danceEveryNumBeats',4)
debugPrint(getProperty('boyfriend.danceEveryNumBeats'))

end

end